import dash
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import requests
from dash import callback_context

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
app.config.suppress_callback_exceptions = True

def fetch_data(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        return None

def create_location_map():
    store_data = fetch_data("http://localhost:5000/api/store_locations")
    customer_data = fetch_data("http://localhost:5000/api/customer_locations")

    if store_data and customer_data:
        store_df = pd.DataFrame(store_data['store_locations'])
        customer_df = pd.DataFrame(customer_data['customer_locations'])

        store_df['Type'] = 'Store'
        customer_df['Type'] = 'Customer'

        data = pd.concat([customer_df, store_df], ignore_index=True)

        fig = go.Figure()
        for type, details in zip(["Customer", "Store"], [{"color": "green", "size": 6}, {"color": "blue", "size": 15}]):
            df = data[data["Type"] == type]
            fig.add_trace(go.Scattergeo(
                lon=df['longitude'],
                lat=df['latitude'],
                text=df['city'] + ' (' + df['Type'] + ')' if 'city' in df.columns else df['Type'], 
                marker=dict(
                    size=details["size"],
                    color=details["color"],
                    line=dict(width=1, color='rgba(0,0,0,0)')
                ),
                hovertemplate='%{text}<extra></extra>',
                name=type
            ))

        focus_lat = 37.7749
        focus_lon = -122.4194

        fig.update_layout(
            showlegend=True,
            legend=dict(
                x=1.05,
                y=0.5,
                font=dict(size=14),
                bgcolor="rgba(0, 0, 0, 0)",
                bordercolor="Black",
                borderwidth=0
            ),
            geo=dict(
                projection_type='albers usa',
                center=dict(lat=focus_lat, lon=focus_lon),
                showland=True,
                landcolor="rgb(217, 217, 217)",
                subunitcolor="rgb(255, 255, 255)",
                subunitwidth=0.5,
                fitbounds="locations",
            ),
            margin={"r":0,"t":0,"l":0,"b":0}
        )
        return fig
    else:
        return go.Figure()

# Funktion zum Erstellen der Sales Heatmap
def create_sales_heatmap(selected_year):
    revenue_data = fetch_data(f"http://localhost:5000/api/store_annual_revenues")
    if revenue_data:
        data = pd.DataFrame(revenue_data['store_annual_revenues'])
        data_year = data[['storeid', 'latitude', 'longitude', 'city', f'revenue_{selected_year}']].copy()
        data_year['Revenue'] = pd.to_numeric(data_year[f'revenue_{selected_year}'])

        data_year = data_year.sort_values(by='Revenue', ascending=False)

        fig = px.scatter_geo(data_year, lat='latitude', lon='longitude', hover_name='city',
                             size='Revenue', color='city',
                             size_max=30, projection='albers usa',
                             custom_data=['storeid'])  # Add storeid to custom_data

        fig.update_traces(hovertemplate='%{hovertext}<br>Revenue: %{marker.size:$,.0f}<br>Store ID: %{customdata[0]}')

        focus_lat = 37.7749
        focus_lon = -122.4194

        fig.update_layout(
            margin={"r":0,"t":0,"l":0,"b":0},
            geo=dict(
                scope='north america',
                center=dict(lat=focus_lat, lon=focus_lon),
                showland=True,
                landcolor='rgb(243, 243, 243)',
                countrycolor='rgb(204, 204, 204)',
                fitbounds="locations",
            )
        )
        return fig
    else:
        return go.Figure()

def create_weekday_revenue_bar_chart(store_id):
    endpoint = "http://localhost:5000/api/revenue_per_weekday"
    data = fetch_data(endpoint)
    
    if data:
        revenue_data = data.get('revenue_per_weekday', [])
        if not revenue_data:
            return go.Figure()

        df = pd.DataFrame(revenue_data)

        df['order_day_of_week'] = pd.to_numeric(df['order_day_of_week'])
        df['total_revenue'] = pd.to_numeric(df['total_revenue'])

        df = df[df['storeid'] == store_id]

        if df.empty:
            return go.Figure()

        days_map = {0: 'Monday', 1: 'Tuesday', 2: 'Wednesday', 3: 'Thursday', 4: 'Friday', 5: 'Saturday', 6: 'Sunday'}
        df['Day'] = df['order_day_of_week'].map(days_map)

        ordered_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        df['Day'] = pd.Categorical(df['Day'], categories=ordered_days, ordered=True)

        fig = px.bar(df, x='Day', y='total_revenue', title=f'Weekly Revenue for Store {store_id}', labels={'Day': 'Day of the Week', 'total_revenue': 'Total Revenue'})
        
        return fig
    else:
        return go.Figure()

def create_hourly_orders_bar_chart(store_id):
    url = "http://localhost:5000/api/store_orders_per_hour"
    data = fetch_data(url)
    
    if data:
        df = pd.DataFrame(data['store_orders_per_hour'])
        df = df[df['storeid'] == store_id]
        
        if df.empty:
            return go.Figure()
        
        df['order_hour'] = df['order_hour'].astype(int)
        bins = [0, 4, 8, 12, 16, 20, 24]
        labels = ['00-04', '04-08', '08-12', '12-16', '16-20', '20-24']
        df['hour_group'] = pd.cut(df['order_hour'], bins=bins, labels=labels, right=False)
        
        grouped_df = df.groupby('hour_group')['total_orders_per_hour'].sum().reset_index()

        fig = px.bar(grouped_df, x='hour_group', y='total_orders_per_hour', title=f'Total Orders per 4-Hour Intervals for Store {store_id}', labels={'hour_group': 'Hour Group', 'total_orders_per_hour': 'Total Orders'})
        
        return fig
    else:
        return go.Figure()

def show_monthly_sales(store_id, year):
    endpoint = f"http://localhost:5000/api/store_monthly_revenues"
    data = fetch_data(endpoint)
    
    if data:
        store_data = next((item for item in data['store_monthly_revenues'] if item['storeid'] == store_id), None)
        
        if store_data:
            monthly_sales_data = {
                month: revenue
                for month, revenue in store_data['monthly_revenues'].items()
                if month.startswith(year)
            }
            
            if monthly_sales_data:
                monthly_sales_df = pd.DataFrame(list(monthly_sales_data.items()), columns=['Month', 'Sales'])
                monthly_sales_df['Month'] = pd.to_datetime(monthly_sales_df['Month'] + '-01')
                monthly_sales_df = monthly_sales_df.set_index('Month').resample('M').sum().reset_index()
                monthly_sales_df['Month'] = monthly_sales_df['Month'].dt.strftime('%B')

                fig = px.bar(monthly_sales_df, x='Month', y='Sales', title=f'Monthly Sales for Store {store_id} in {year}', labels={'Month': 'Month', 'Sales': 'Sales'})
                return fig
            else:
                return go.Figure()
        else:
            return go.Figure()
    else:
        return go.Figure()

def create_grouped_bar_chart(store1, store2):
    endpoint = f"http://localhost:5000/api/store_yearly_avg_orders"
    data = fetch_data(endpoint)
    
    if data:
        if store2 == "None":
            df_filtered = [item for item in data if item['storeid'] == store1]
        else:
            df_filtered = [item for item in data if item['storeid'] in [store1, store2]]
        
        df_grouped = pd.DataFrame(df_filtered)
        df_grouped = df_grouped.groupby(['year', 'storeid'])['avg_orders_per_customer'].sum().reset_index()
        
        df_grouped['avg_orders_per_customer'] = df_grouped['avg_orders_per_customer'].round().astype(int)

        fig = go.Figure()

        for store in [store1, store2]:
            if store == "None":
                continue
            df_store = df_grouped[df_grouped['storeid'] == store]
            fig.add_trace(go.Bar(
                x=df_store['year'],
                y=df_store['avg_orders_per_customer'],
                name=store,
                hovertemplate='Year: %{x}<br>Orders: %{y}'
            ))

        fig.update_layout(
            barmode='group',
            title='Customer Reorder Comparison',
            xaxis_title='Year',
            yaxis_title='Repeat Purchases',
            xaxis=dict(type='category')
        )

        return fig
    else:
        return go.Figure()

def create_pizza_scatter_plot():
    url = "http://localhost:5000/api/scatter_plot_pizzen"
    scatter_data = fetch_data(url)
    
    if scatter_data:
        df = pd.DataFrame(scatter_data)
        
        fig = go.Figure()
        
        unique_pizza_names = df['pizza_name'].unique()
        unique_pizza_sizes = df['pizza_size'].unique()
        colors = px.colors.qualitative.Plotly
        
        color_map = {
            'Margherita Pizza': colors[0],
            'Pepperoni Pizza': 'peru',
            'Hawaiian Pizza': 'brown',  
            'Meat Lover\'s Pizza': colors[3],
            'Veggie Pizza': 'yellow',
            'BBQ Chicken Pizza': colors[5],
            'Buffalo Chicken Pizza': colors[6],
            'Sicilian Pizza': 'snow',
            'Oxtail Pizza': 'grey',
        }
        
        markers = ['circle', 'square', 'diamond', 'cross', 'x', 'triangle-up', 'triangle-down', 'triangle-left', 'triangle-right']
        
        for pizza_name in unique_pizza_names:
            for pizza_size in unique_pizza_sizes:
                df_filtered = df[(df['pizza_name'] == pizza_name) & (df['pizza_size'] == pizza_size)]
                if not df_filtered.empty:
                    fig.add_trace(go.Scatter(
                        x=df_filtered['total_sold'],
                        y=df_filtered['total_revenue'],
                        mode='markers',
                        marker=dict(
                            size=10,
                            color=color_map.get(pizza_name, 'black'),
                            symbol=markers[list(unique_pizza_sizes).index(pizza_size) % len(markers)]
                        ),
                        name=f'{pizza_name} ({pizza_size})',
                        hovertemplate=f'<b>Pizza:</b> {pizza_name} ({pizza_size})<br><b>Sold Pizzas:</b> %{{x}}<br><b>Revenue:</b> %{{y:.2f}}M USD<extra></extra>'
                    ))
        
        fig.update_layout(
            title='Pizza Sales and Revenue by Type and Size',
            xaxis_title='Number of Pizzas Sold',
            yaxis_title='Total Revenue (USD)',
            legend_title='Pizza (Size)',
            showlegend=True
        )
        
        return fig
    else:
        return go.Figure()

def create_pizza_donut():
    url = "http://localhost:5000/api/revenues_by_pizza_type_2022"
    donut_data = fetch_data(url)

    if donut_data:
        df_pizza = pd.DataFrame(donut_data['revenues_by_pizza_type_2022'])

        fig = px.pie(df_pizza, values='total_revenue', names='pizza_name', hole=0.3, title='Revenue by Pizza Type (2022)')
        fig.update_traces(
            textinfo='label',
            hovertemplate='<b>%{label}</b><br>Revenue: $%{value:,.2f}<br>Percentage: %{percent:.2%}'
        )

        fig.update_layout(
            margin=dict(t=50, b=50, l=50, r=50),
            height=550,
        )
        
        return fig
    else:
        return go.Figure()
    
def create_scatter_plots():
    scatter_data = fetch_data("http://localhost:5000/api/scatterplot")
    if scatter_data:
        df = pd.DataFrame(scatter_data)
        
        df.rename(columns={"storeid": "Store ID", "year": "Year", "order_count": "Orders", "revenue": "Revenue"}, inplace=True)

        df['Orders'] = pd.to_numeric(df['Orders']).apply(lambda x: round(x))
        df['Revenue'] = pd.to_numeric(df['Revenue']).round(1)

        fig = px.scatter(
            df,
            x='Orders',
            y='Revenue',
            color='Store ID',
            facet_col='Year',
            trendline='ols',
            trendline_scope='overall',
            trendline_color_override='cyan',
            labels={'Orders': 'Total Orders', 'Revenue': 'Revenue'}
        )

        trendline_traces = [trace for trace in fig.data if 'trendline' in trace.name]
        scatter_traces = [trace for trace in fig.data if 'trendline' not in trace.name]

        fig.data = ()
        for trace in trendline_traces + scatter_traces:
            fig.add_trace(trace)

        fig.update_traces(
            hovertemplate='<br><b>Store ID:</b> %{customdata[0]}<br>'
                          '<b>Total Orders:</b> %{x:.0f}<br>'
                          '<b>Revenue:</b> %{y:.1f}k<extra></extra>',
            customdata=df[['Store ID']]
        )

        fig.for_each_annotation(lambda a: a.update(text=a.text.split("=")[-1]))

        fig.update_layout(
            margin={"r":0,"t":30,"l":0,"b":0},
            xaxis_tickformat=',d',
            yaxis_tickformat=',.1f'
        )

        return fig
    else:
        return go.Figure()


def create_top_5_stores_table():
    data = fetch_data("http://localhost:5000/api/top_5_stores")
    if data and "top_5_stores" in data:
        df = pd.DataFrame(data["top_5_stores"])
        tables = []
        for year in [2020, 2021, 2022]:
            df_year = df[df['year'] == year].sort_values(by='annual_sales', ascending=False).reset_index(drop=True)
            df_year.index = df_year.index + 1
            df_year = df_year[['storeid', 'annual_sales']]
            df_year.columns = ['Store ID', 'Revenue']
            tables.append(html.Div([
                html.H5(f"Top 5 Stores in {year}"),
                dbc.Table.from_dataframe(df_year, striped=True, bordered=True, hover=True)
            ]))
        return html.Div(tables)
    return "No data available"

def create_worst_5_stores_table():
    data = fetch_data("http://localhost:5000/api/worst_5_stores")
    if data and "worst_5_stores" in data:
        df = pd.DataFrame(data["worst_5_stores"])
        tables = []
        for year in [2020, 2021, 2022]:
            df_year = df[df['year'] == year].sort_values(by='annual_sales', ascending=True).reset_index(drop=True)
            df_year.index = df_year.index + 1
            df_year = df_year[['storeid', 'annual_sales']]
            df_year.columns = ['Store ID', 'Revenue']
            tables.append(html.Div([
                html.H5(f"Worst 5 Stores in {year}"),
                dbc.Table.from_dataframe(df_year, striped=True, bordered=True, hover=True)
            ]))
        return html.Div(tables)
    return "No data available"

# Layout der App
app.layout = html.Div([
    dcc.Location(id='url', refresh=False),  # Location-Komponente hinzugefügt
    dbc.Row([
        dbc.Col(html.Img(src="assets/CaptainPizza.png", style={"width": "200px"}), width=2),
        dbc.Col(html.H1("Pizzeria Dashboard", className="text-center"), width=8)
    ]),
    dbc.Row([
        dbc.Col(dbc.Card(dbc.CardBody([
            html.H5("New Customers 2022"),
            html.H2(id="new-customers", className="card-title")
        ])), width=4),
        dbc.Col(dbc.Card(dbc.CardBody([
            html.H5("Total Revenue 2022"),
            html.H2(id="total-revenue", className="card-title")
        ])), width=4),
        dbc.Col(dbc.Card(dbc.CardBody([
            html.H5("Average Revenue for Store 2022"),
            html.H2(id="avg-revenue-per-store", className="card-title")
        ])), width=4)
    ]),
    dcc.Tabs([
        dcc.Tab(label='Overview', children=[
            dbc.Row([
                dbc.Col(html.Div(id='top-5-good-stores'), width=6),
                dbc.Col(html.Div(id='top-5-bad-stores'), width=6)
            ]),
            dbc.Row([
                dbc.Col(html.Div([
                    dcc.Dropdown(
                        id='overview-store-dropdown',
                        options=[{'label': store_id, 'value': store_id} for store_id in fetch_data("http://localhost:5000/api/store_ids")['store_ids']],
                        value=None
                    )
                ]), width=12)
            ]),
            dbc.Row([
                dbc.Col(dcc.Graph(id='scatterplot-pizza-orders'), width=12)
            ]),
            dbc.Row([
                dbc.Col(dcc.Graph(id='pizza-donut'), width=12)
            ])
        ]),
        dcc.Tab(label='Storeview', children=[
            dbc.Row([
                dbc.Col(html.Div([
                    dcc.Dropdown(
                        id='year-dropdown',
                        options=[{'label': str(year), 'value': year} for year in range(2018, 2023)],
                        value=2022
                    ),
                    dcc.Dropdown(
                        id='store-dropdown',
                        options=[{'label': store_id, 'value': store_id} for store_id in fetch_data("http://localhost:5000/api/store_ids")['store_ids']],
                        value=None
                    )
                ]), width=12)
            ]),
            dbc.Row([
                dbc.Col(dcc.Graph(id='revenue-map'), width=6),
                dbc.Col(dcc.Graph(figure=create_location_map()), width=6)
            ]),
            dbc.Row([
                dbc.Col(html.Div([
                    dcc.Graph(id='weekly-revenue-chart')
                ]), width=6),
                dbc.Col(html.Div([
                    dcc.Graph(id='hourly-orders-chart')
                ]), width=6)
            ]),
            dbc.Row([
                dbc.Col(html.Div([
                    dcc.Graph(id='monthly-revenue')
                ]), width=6),
                dbc.Col(dcc.Graph(id='repeat-order'), width=6)
            ])
        ]),
        dcc.Tab(label='Customerview', children=[
            dbc.Row([
                dbc.Col(html.Div([
                    dcc.Dropdown(
                        id='customer-dropdown',
                        options=[{'label': store_id, 'value': store_id} for store_id in fetch_data("http://localhost:5000/api/store_ids")['store_ids']],
                        value=None
                    )
                ]), width=12)
            ]),
            dbc.Row([
                dbc.Col(dcc.Graph(id='customer-location-map'), width=6),
                dbc.Col(dcc.Graph(id='repeat-order-customer'), width=6)
            ])
        ])
    ])
])
# Callbacks für die Aktualisierung der Metriken und Diagramme
@app.callback(
    [
        Output('new-customers', 'children'),
        Output('total-revenue', 'children'),
        Output('avg-revenue-per-store', 'children')
    ],
    [Input('url', 'pathname')]
)
def update_metrics(_):
    metrics = fetch_data("http://localhost:5000/api/metrics")
    if metrics:
        new_customers_2022 = metrics.get('new_customers_2022', 0)
        new_customers_change = metrics.get('new_customers_change', 0.0)
        total_revenue_2022 = metrics.get('total_revenue_2022', 0.0)
        total_revenue_change = metrics.get('total_revenue_change', 0.0)
        avg_revenue_per_store_2022 = metrics.get('avg_revenue_per_store_2022', 0.0)
        avg_revenue_per_store_change = metrics.get('avg_revenue_per_store_change', 0.0)

        return [
            f"{new_customers_2022} ({new_customers_change:.2f}%)",
            f"${total_revenue_2022 / 1e6:,.2f} Mio ({total_revenue_change:.2f}%)",
            f"${avg_revenue_per_store_2022 / 1e6:,.2f} Mio ({avg_revenue_per_store_change:.2f}%)"
        ]
    return ["No data", "No data", "No data"]

@app.callback(
    [
        Output('revenue-map', 'figure'),
        Output('weekly-revenue-chart', 'figure'),
        Output('hourly-orders-chart', 'figure'),
        Output('monthly-revenue', 'figure'),
        Output('repeat-order', 'figure')
    ],
    [
        Input('year-dropdown', 'value'),
        Input('store-dropdown', 'value')
    ]
)
def update_storeview_charts(selected_year, selected_store):
    if not selected_year or not selected_store:
        return [go.Figure()] * 5

    revenue_map_fig = create_sales_heatmap(selected_year)
    weekly_revenue_fig = create_weekday_revenue_bar_chart(selected_store)
    hourly_orders_fig = create_hourly_orders_bar_chart(selected_store)
    monthly_revenue_fig = show_monthly_sales(selected_store, str(selected_year))
    repeat_order_fig = create_grouped_bar_chart(selected_store, 'None')
    
    return revenue_map_fig, weekly_revenue_fig, hourly_orders_fig, monthly_revenue_fig, repeat_order_fig

@app.callback(
    [
        Output('scatterplot-pizza-orders', 'figure'),
        Output('pizza-donut', 'figure')
    ],
    [Input('overview-store-dropdown', 'value')]
)
def update_overview_charts(selected_store):
    ctx = dash.callback_context
    if not ctx.triggered:
        return [go.Figure()] * 2
    
    input_id = ctx.triggered[0]['prop_id'].split('.')[0]
    
    if input_id == 'overview-store-dropdown':
        scatterplot_pizza_orders_fig = create_scatter_plots()  # Modify if needed to filter by store
        pizza_donut_fig = create_pizza_donut()  # Modify if needed to filter by store
        
        return scatterplot_pizza_orders_fig, pizza_donut_fig
    
    return [go.Figure()] * 2

@app.callback(
    [
        Output('customer-location-map', 'figure'),
        Output('repeat-order-customer', 'figure')
    ],
    [Input('customer-dropdown', 'value')]
)
def update_customer_charts(selected_store):
    ctx = dash.callback_context
    if not ctx.triggered:
        return [go.Figure()] * 2
    
    input_id = ctx.triggered[0]['prop_id'].split('.')[0]
    
    if input_id == 'customer-dropdown':
        location_map_fig = create_location_map()  # Modify if needed to filter by store
        repeat_order_customer_fig = create_grouped_bar_chart(selected_store, 'None')  # Modify if needed to filter by store
        
        return location_map_fig, repeat_order_customer_fig
    
    return [go.Figure()] * 2

# Callback zur Aktualisierung des Dropdown-Werts basierend auf der Auswahl in der Heatmap
@app.callback(
    Output('store-dropdown', 'value'),
    [Input('revenue-map', 'clickData')]
)
def update_store_dropdown(click_data):
    if click_data and 'points' in click_data:
        selected_store = click_data['points'][0]['customdata'][0]
        return selected_store
    return None

if __name__ == '__main__':
    app.run_server(debug=True)
